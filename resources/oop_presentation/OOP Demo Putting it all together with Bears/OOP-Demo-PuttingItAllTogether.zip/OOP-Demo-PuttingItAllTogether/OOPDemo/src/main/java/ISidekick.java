public interface ISidekick {

    Sidekick getSideKick();
}
