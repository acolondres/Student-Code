public interface Bear {

    int getHeight();
    String getFurColor();
}
