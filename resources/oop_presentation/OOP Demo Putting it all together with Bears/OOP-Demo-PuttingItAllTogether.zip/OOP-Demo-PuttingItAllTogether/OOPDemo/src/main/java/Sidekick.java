public class Sidekick {
}
